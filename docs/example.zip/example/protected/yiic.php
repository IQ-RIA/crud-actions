<?php

// change the following paths if necessary
$yiic=dirname(__FILE__).'/../../yii-1.1.12.b600af/framework/yiic.php';
$config=dirname(__FILE__).'/config/console.php';

require_once($yiic);
