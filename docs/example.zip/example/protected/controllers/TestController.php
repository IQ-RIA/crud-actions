<?php

class TestController extends Controller {

	public function actions() {
		Yii::import('application.extensions.crud-actions.*');
		// return external action classes, e.g.:
		return array(
			'index' => array(
				'class' => 'application.extensions.crud-actions.ListAction',
				'className' => 'Test',
			),
			'view' => array(
				'class' => 'application.extensions.crud-actions.ViewAction',
				'className' => 'Test',
				'viewId' => 'id'
			),
			'create' => array(
				'class' => 'application.extensions.crud-actions.PostAction',
				'className' => 'Test',
				'form' => $_POST,
				'viewFunction' => function ($model ) {
					return $model->toArray();
				}
			),
			'update' => array(
				'class' => 'application.extensions.crud-actions.PutAction',
				'className' => 'Test',
				'viewId' => 'id',
				'form' => $_POST,
				'viewFunction' => function ($model ) {
					return $model->toArray();
				}
			),
		);
	}

	public function end($data) {
		echo CJSON::encode($data);
	}

}